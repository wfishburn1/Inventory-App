package com.example.projectthree;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {

    EditText editTextUsername, editTextPassword;
    Button buttonCreateAccount, buttonDeleteAccount, buttonUpdatePassword;
    UserDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        dbHelper = new UserDatabaseHelper(this);

        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();
                boolean inserted = dbHelper.insertAccount(username, password);
                if (inserted) {
                    Log.d("CreateAccountActivity", "Account created successfully"); // Add log statement
                    Toast.makeText(CreateAccountActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Log.d("CreateAccountActivity", "Failed to create account"); // Add log statement
                    Toast.makeText(CreateAccountActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonDeleteAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                boolean deleted = dbHelper.deleteAccount(username);
                if (deleted) {
                    Log.d("CreateAccountActivity", "Account deleted successfully");
                    Toast.makeText(CreateAccountActivity.this, "Account deleted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Log.d("CreateAccountActivity", "Failed to delete account");
                    Toast.makeText(CreateAccountActivity.this, "Failed to delete account", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonUpdatePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String newPassword = editTextPassword.getText().toString();
                boolean updated = dbHelper.updatePassword(username, newPassword);
                if (updated) {
                    Log.d("CreateAccountActivity", "Password updated successfully");
                    Toast.makeText(CreateAccountActivity.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Log.d("CreateAccountActivity", "Failed to update password");
                    Toast.makeText(CreateAccountActivity.this, "Failed to update password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

