package com.example.projectthree;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SecondFragment extends Fragment {
    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private EditText editTextData;
    private Button buttonAddData;
    private Button buttonLogout;
    private ItemDatabaseHelper dbHelper;

    // Request code for SMS permission
    private static final int REQUEST_SMS_PERMISSION = 123;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @SuppressLint("WrongViewCast")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recyclerViewData);
        editTextData = view.findViewById(R.id.editDataValue);
        buttonAddData = view.findViewById(R.id.buttonAddData);
        buttonLogout = view.findViewById(R.id.buttonSecond);

        dbHelper = new ItemDatabaseHelper(requireContext());

        // Load existing items from the database
        List<Item> itemList = dbHelper.getAllItems();
        adapter = new ItemAdapter(itemList);
        adapter.setEditingMode(true); // Set editing mode to true initially
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Set OnClickListener for delete button in ItemAdapter
        adapter.setOnDeleteItemClickListener(new ItemAdapter.OnDeleteItemClickListener() {
            @Override
            public void onDeleteItemClick(int position) {
                // Remove the item from the database
                dbHelper.deleteItem(itemList.get(position).getId());
                // Remove the item from the RecyclerView
                adapter.deleteItem(position);
            }
        });

        buttonAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = editTextData.getText().toString().trim();
                int quantity = 1;
                int id = 0;

                if (!data.isEmpty()) {
                    Item newItem = new Item(id, data, quantity);
                    boolean inserted = dbHelper.insertItem(newItem);
                    if (inserted) {
                        Toast.makeText(requireContext(), "Data added successfully", Toast.LENGTH_SHORT).show();
                        // Reload items from the database
                        adapter.setItems(dbHelper.getAllItems());
                        editTextData.setText("");

                        // Check and request SMS permission
                        if (checkSmsPermission()) {
                            sendSmsNotification("Data added successfully");
                        }
                    } else {
                        Toast.makeText(requireContext(), "Failed to add data", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(requireContext(), "Please enter data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the FirstFragment
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });

        // Check if itemList is empty and send SMS notification if true
        if (itemList.isEmpty()) {
            if (checkSmsPermission()) {
                sendSmsNotification("No items to display");
            }
        }

        // Context from the activity
        Context context = getContext();

        // Creating Item objects for three new items
        Item item1 = new Item(0, "mkt", 10);
        Item item2 = new Item(1, "tmp", 15);
        Item item3 = new Item(2, "tmp1", 20);

        // Inserting each item into the database
        boolean inserted1 = dbHelper.insertItem(item1);
        boolean inserted2 = dbHelper.insertItem(item2);
        boolean inserted3 = dbHelper.insertItem(item3);

        if (inserted1 && inserted2 && inserted3) {
            Log.d("SQLite", "All items added successfully");
        } else {
            Log.d("SQLite", "Failed to add one or more items to the database");
        }
    }

    // Method to check SMS permission and request if not granted
    private boolean checkSmsPermission() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Permission not granted, request it
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
            }
            return false;
        }
        return true;
    }

    // Method to send SMS notification
    private void sendSmsNotification(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("PhoneNumberHere", null, message, null, null);
            Toast.makeText(requireContext(), "SMS Sent!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(requireContext(), "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    // Handle SMS permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send SMS
                sendSmsNotification("No items to display");
            } else {
                // Permission denied
                Toast.makeText(requireContext(), "SMS permission denied. Cannot send SMS notification.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
