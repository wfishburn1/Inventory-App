package com.example.projectthree;

import android.annotation.SuppressLint;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {
    private List<Item> itemList;
    private boolean isEditingMode = false; // Flag to track editing mode
    private static OnDeleteItemClickListener onDeleteItemClickListener;

    // Constructor
    public ItemAdapter(List<Item> itemList) {
        this.itemList = itemList;
    }

    public void deleteItem(int position) {
    }

    // Interface for handling delete item clicks
    public interface OnDeleteItemClickListener {
        void onDeleteItemClick(int position);
    }

    // Method to set the delete item click listener
    public void setOnDeleteItemClickListener(OnDeleteItemClickListener listener) {
        onDeleteItemClickListener = listener;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item item = itemList.get(position);
        if (isEditingMode) {
            // Bind EditText fields for editing item details
            holder.bindEditable(item);
        } else {
            // Bind TextViews for displaying item details
            holder.bind(item);
        }
    }

    public void setEditingMode(boolean isEditing) {
        isEditingMode = isEditing;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view, this); // Pass the ItemAdapter instance to the ViewHolder constructor
    }


    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // Method to add a new item to the list
    public void addItem(Item item) {
        itemList.add(item);
        notifyItemInserted(itemList.size() - 1);
    }

    public void setItems(List<Item> itemList) {
        this.itemList = itemList;
        notifyDataSetChanged(); // Notify adapter that dataset has changed
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textViewName;
        private EditText editTextName; // Add EditText field for editing
        private ItemAdapter adapter; // Reference to the ItemAdapter instance

        public ViewHolder(@NonNull View itemView, ItemAdapter adapter) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textData);
            editTextName = itemView.findViewById(R.id.editTextItemName); // Initialize EditText
            this.adapter = adapter; // Assign the ItemAdapter instance
            View deleteButton = itemView.findViewById(R.id.buttonDelete); // Initialize delete button

            // Set OnClickListener for delete button
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && onDeleteItemClickListener != null) {
                        onDeleteItemClickListener.onDeleteItemClick(position);
                    }
                }
            });

            // Add a text change listener to EditText
            editTextName.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    // Update the item's name when the text changes
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        Item item = adapter.getItemList().get(position);
                        item.setName(s.toString());
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                    // No implementation needed
                }
            });
        }

        public void bind(Item item) {
            textViewName.setText(item.getName());
            editTextName.setVisibility(View.GONE); // Hide EditText in display mode
        }

        public void bindEditable(Item item) {
            editTextName.setVisibility(View.VISIBLE); // Show EditText in editing mode
            editTextName.setText(item.getName()); // Set EditText text
        }
    }
    public List<Item> getItemList() {
        return itemList;
    }

}