package com.example.projectthree;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;


public class ItemDatabaseHelper extends SQLiteOpenHelper {

    // Define constants for the database name, table name, and column names
    private static final String DATABASE_NAME = "ItemDatabase.db";
    private static final String TABLE_NAME = "items";
    private static final String COL_ID = "id";
    private static final String COL_NAME = "name";
    private static final String COL_QUANTITY = "quantity";

    // Constructor for the ItemDatabaseHelper class
    public ItemDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    // Override the onCreate method to create the database table
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_QUANTITY + " INTEGER)";
        db.execSQL(createTableQuery);
    }

    // Override the onUpgrade method to handle database schema upgrades
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Method to insert a new item into the database
    public boolean insertItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, item.getName());
        values.put(COL_QUANTITY, item.getQuantity());
        long result = db.insert(TABLE_NAME, null, values);
        return result != -1;
    }

    // Method to delete an item from the database
    public boolean deleteItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_NAME, COL_ID + "=?", new String[]{String.valueOf(itemId)});
        return result > 0;
    }

    // Method to update an existing item in the database
    public boolean updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, item.getName());
        values.put(COL_QUANTITY, item.getQuantity());
        int result = db.update(TABLE_NAME, values, COL_ID + "=?", new String[]{String.valueOf(item.getId())});
        return result > 0;
    }

    // Method to retrieve all items from the database
    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int itemIdIndex = cursor.getColumnIndexOrThrow(COL_ID);
                int itemNameIndex = cursor.getColumnIndexOrThrow(COL_NAME);
                int itemQuantityIndex = cursor.getColumnIndexOrThrow(COL_QUANTITY);

                int itemId = cursor.getInt(itemIdIndex);
                String itemName = cursor.getString(itemNameIndex);
                int itemQuantity = cursor.getInt(itemQuantityIndex);

                Item item = new Item(itemId, itemName, itemQuantity);
                itemList.add(item);
            }
            cursor.close();
        }
        return itemList;
    }

}
